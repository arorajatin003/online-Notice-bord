//jshint esversion:6

const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const _ = require("lodash");
const mongoose = require('mongoose');



const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

mongoose.connect("mongodb+srv://Jatin-arora-admin:Jatinarora003@cluster0.osicw.mongodb.net/gramPanchayatDB", {useNewUrlParser: true});

const postSchema = {
  title: String,
  content: String
};

const Post = mongoose.model("Post", postSchema);


app.get("/", function(req, res){

  Post.find({}, function(err, posts){
    res.render("index", {
      posts: posts;
      });
  });
});

app.get("/add", function(req, res){
  res.render("add");
});

app.post("/add", function(req, res){
  const post = new Post({
    title: req.body.title,
    content: req.body.content
  });
  post.save(function(err){
    if (!err){
        res.redirect("/");
    }
  });
  console.log(post.title);
});

app.get("/posts/:postId", function(req, res){

const requestedPostId = req.params.postId;
console.log(requestedPostId );
  Post.findOne({title: requestedPostId}, function(err, post){
    console.log("   "+post.title);
    res.render("post", {
      posts: post
    });
  });

});

app.get("/about", function(req, res){
  res.render("aboutus", {});
});

app.get("/help", function(req, res){
  res.render("help", {});
});
app.get("/delete",function(req,res){
  Post.find({}, function(err, posts){
    res.render("delete", {
      posts: posts
      });
});
});
app.post("/delete", function(req, res){
  const checkedItemId = req.body.checkbox;
  console.log(checkedItemId);
    Post.findByIdAndRemove(checkedItemId, function(err){
      if (!err) {
        console.log("Successfully deleted checked item.");
        res.redirect("/");
      }
    });
  });
  app.get("/navapur",function(req,res){
    res.redirect("/");
  });
  app.get("/shahadra",function(req,res){
    res.redirect("/");
  });
  app.get("/tolada",function(req,res){
    res.redirect("/");
  });
  app.get("/akkalku",function(req,res){
    res.redirect("/");
  });
  app.get("/akran",function(req,res){
    res.redirect("/");
  });

app.listen(3000, function() {
  console.log("Server started on port 3000");
});
